// src/pages/RisikoSpredning.tsx
import React from 'react';
import { Typography } from '@mui/material';

const RisikoSpredning: React.FC = () => {
  return <Typography variant="h4">Indhold for Risiko Spredning</Typography>;
};

export default RisikoSpredning;
